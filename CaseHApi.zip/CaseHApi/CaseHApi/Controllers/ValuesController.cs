﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Data;
using System.Data.SqlClient;
using CaseHApi.Access;

namespace CaseHApi.Controllers
{
    public class ValuesController : ApiController
    {
        // GET api/values
        public DataTable Get()
        {
            string sqlString = "[dbo].[SystemCode_GetById]";
            SqlParameter[] par = new SqlParameter[3];

            par[0] = new SqlParameter("@UserSessionId", SqlDbType.VarChar, 24); par[0].Value = "5xz2zuf2pzuzbzp4dkeb3zjf";
            par[1] = new SqlParameter("@Id", SqlDbType.Int); par[1].Value = 12;
            par[2] = new SqlParameter("@ret", SqlDbType.Int); par[2].Direction = ParameterDirection.ReturnValue;

            DataTable tblCurrent = SqlHelper.ExecuteDataTable("Server=URAN; initial catalog=TestCaseHistory; user id = 'CaseHistoryUser';password ='CH';Max Pool Size=200;", CommandType.StoredProcedure, sqlString, par);
            if (Convert.ToInt32(par[2].Value) != 0)
                return null;

            return tblCurrent;
        }

        // GET api/values/5
        public string Get(int id)
        {
            return "value";
        }

        // POST api/values
        public void Post([FromBody]string value)
        {
        }

        // PUT api/values/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/values/5
        public void Delete(int id)
        {
        }
    }
}
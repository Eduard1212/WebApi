﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Data;
using System.Data.SqlClient;
using CaseHApi.Appointment;

namespace CaseHApi.Controllers
{
    public class AppointmentController : ApiController
    {
        [HttpGet]  // GET api/values?log=XXX&pas=XXX
        public DataTable GetAppoint(string s, string type, int? illId, string illNum)
        {
            DataTable dtAppoint = Appoint.GetAppointList(s, DateTime.Now.Date, DateTime.Now.Date, illId, illNum, type);
            dtAppoint.TableName = "appoints";
            if (dtAppoint != null && dtAppoint.Rows.Count > 0)
                return dtAppoint;
            else
                return null;
        }

        [HttpGet]
        public string UpdateAppoint(string s, int ID, int st, int phys, int room)
        {
            return Appoint.UpdateAppoint(s, ID, st, "", Convert.ToInt32(Appoint.GetPhysicianID(s)), 0, 0, room, 0);
        }

        [HttpGet]
        public DataTable GetTypeList(string s)
        {
            DataTable dtType = Appoint.GetTypeList(s);
            if (dtType != null && dtType.Rows.Count > 0)
                return dtType;
            else
                return null;
        }
    }
}

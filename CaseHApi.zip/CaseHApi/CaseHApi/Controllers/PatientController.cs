﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Data;
using System.Data.SqlClient;
using CaseHApi.Patients;

namespace CaseHApi.Controllers
{
    public class PatientController : ApiController
    {
        [HttpGet]  // GET api/values?log=XXX&pas=XXX
        public DataTable GetPatient(string s, string illNum)
        {
            DataTable dtPatient = Patient.GetPatientList(s, DateTime.MinValue , DateTime.MinValue, illNum);
            if (dtPatient != null && dtPatient.Rows.Count > 0)
                return dtPatient;
            else
                return null;
        }

        [HttpGet]
        public string UpdatePatient(string s, int IllId, int? BedId, byte? IsSp, byte? IsFr, byte? St)
        {
            if (Patient.BedIsFree(s, BedId == null ? int.MinValue + 1 : BedId.Value)) 
                return Patient.UpdatePatientBed(s, IllId, BedId, IsSp, IsFr, St);
            else return "Данная койка занята другим пациентом!";
        }

        [HttpGet]
        public string PhysicianBySession(string s)
        {
            return Patient.GetPhysicianID(s);
        }
    }
}

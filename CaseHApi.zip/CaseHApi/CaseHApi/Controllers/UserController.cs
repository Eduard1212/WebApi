﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.SessionState;
using System.Data;
using System.Data.SqlClient;
using CaseHApi.Access;
using CaseHApi.User;
using CaseHApi.UniqueKeyGenerator;

namespace CaseHApi.Controllers
{
    public class UserController : ApiController
    {
        private String connectionString = System.Configuration.ConfigurationManager.AppSettings["ConnectionString"];
        public HttpSessionState Session;

        [HttpGet]  // GET api/values?log=XXX&pas=XXX
        public string LogIn(string log, string pas)
        {
            String SessionId = UniqueKeyGenerator.UniqueKeyGenerator.generateUniqueKey(24);
            
            DataTable dtUser = UserAuth.Verification(log);
            if (dtUser.Rows.Count != 1)
                return "-1";
            var hash = (dtUser.Rows[0]["Passhash"] != DBNull.Value ? dtUser.Rows[0]["Passhash"] : null) as string;
            if (string.IsNullOrEmpty(hash) || hash.Length != 48)
                return "-1";

            int retval = 0;
            if (UserAuth.CheckPassword(pas, hash))
                retval = UserAuth.Authorization(SessionId, (int)dtUser.Rows[0]["UserId"], log, "", "");
            if(retval > 0)
                return SessionId;
            else
                return "-1";
        }

        [HttpGet]  // GET api/values?session=XXXXXX
        public string LogOff(string session)
        {
            if (UserAuth.Exit(session) < 0)
                return "-1";
            return "1";
        }

        [HttpGet]  // GET api/values?s=XXX
        public string GetUserName(string s)
        {
            return UserAuth.GetUserBySessionId(s);
        }

    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Text;
using System.Data.SqlClient;
using CaseHApi.Access;

namespace CaseHApi.Patients
{
    public sealed class Patient
    {
        public static DataTable GetPatientList(string session, DateTime from, DateTime to, string illhNUM)
        {
            DataTable dt;
            string sqlString = "[dbo].[IllHistory_ListForPost]";
            SqlParameter ret;
            try
            {
                dt = SqlHelper.ExecuteDataTable(GetConnectionString(), CommandType.StoredProcedure, sqlString, new[] {
                    new SqlParameter("@UserSessionId", SqlDbType.VarChar, 24) { Value = session }
                    , new SqlParameter("@IllHistoryNum", SqlDbType.VarChar, 10) { Value = illhNUM }
                    , new SqlParameter("@WardId", SqlDbType.VarChar, 5) { Value = "" }
                    , new SqlParameter("@BuildingId", SqlDbType.Int) { Value = DBNull.Value }
                    , new SqlParameter("@Stor", SqlDbType.VarChar, 5) { Value = "" }
                    , new SqlParameter("@PatientLName", SqlDbType.VarChar, 30) { Value = "" }
                    , new SqlParameter("@PatientFName", SqlDbType.VarChar, 30) { Value = "" }
                    , new SqlParameter("@DepartId", SqlDbType.Int) { Value = DBNull.Value }
                    , new SqlParameter("@HospitStatus", SqlDbType.TinyInt) { Value = 0 }
                    , new SqlParameter("@IsAno", SqlDbType.TinyInt) { Value = 0 }
                    , new SqlParameter("@FromDate", SqlDbType.DateTime) { Value = DBNull.Value }
                    , new SqlParameter("@ToDate", SqlDbType.DateTime) { Value = DBNull.Value }
                    , ret = new SqlParameter("@ret", SqlDbType.Int) { Direction = ParameterDirection.ReturnValue }
                });
            }
            catch (Exception ex)
            {
                return null;
            }
            return dt;
        }

        public static string UpdatePatientBed(string s, int IllId, int? BedId, byte? IsSp, byte? IsFr, byte? St)
        {
            int success = int.MinValue + 1;
            string sqlString = "[dbo].[IllHistory_setBed]";
            try
            {
                success = SqlHelper.ExecuteNonQuery(GetConnectionString(), CommandType.StoredProcedure, sqlString, new[] {
                      new SqlParameter("@UserSessionId", SqlDbType.VarChar, 24) { Value = s }
                    , new SqlParameter("@Id", SqlDbType.Int) { Value = IllId }
                    , new SqlParameter("@BedId", SqlDbType.Int) { Value = BedId }
                    , new SqlParameter("@IsSpecial", SqlDbType.TinyInt) { Value = IsSp == null ? 0 : IsSp} //специальная ли койка
                    , new SqlParameter("@IsFreeBed", SqlDbType.TinyInt) { Value = 0 } // освобождается ли койка
                    , new SqlParameter("@IsFree", SqlDbType.TinyInt) { Value = IsFr == null ? 0 : IsFr } // резервация ??
                    , new SqlParameter("@PlanMoveDate", SqlDbType.DateTime) { Value = DateTime.Parse("01.01.1900 0:00:00")} // плановая дата выписки пациента с койки
                    , new SqlParameter("@Status", SqlDbType.TinyInt) { Value = St == null ? 0 : St } // ставим 0
                    , new SqlParameter("@MoveDate", SqlDbType.DateTime) { Value = DateTime.Parse("01.01.1900 0:00:00") } // Дата выписки с койки, но не в случае когда пациента перемещают на новую койку, обычно не ставится
                });
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            if (success == 5)
                return "Пациент успешно обновлен!";
            else return "Ошибка обновления!";
        }

        public static bool BedIsFree(string session, int BedId)
        {
            DataTable patients = null;
            patients = GetPatientList(session, DateTime.Now.AddDays(-30), DateTime.Now.AddDays(+10), "");
            if (patients != null && patients.Rows.Count > 0)
            {
                foreach (DataRow row in patients.Rows)
                {
                    if (row["BEDID"].ToString() == BedId.ToString())
                        return false;
                }
                return true;
            }
            else return true;
        }

        public static string GetPhysicianID(string session)
        {
            DataTable dt;
            string sqlString = "[dbo].[Physician_ListByUserName]";
            SqlParameter ret;
            try
            {
                dt = SqlHelper.ExecuteDataTable(GetConnectionString(), CommandType.StoredProcedure, sqlString, new[] {
                    new SqlParameter("@UserSessionId", SqlDbType.VarChar, 24) { Value = session }
                    , ret = new SqlParameter("@ret", SqlDbType.Int) { Direction = ParameterDirection.ReturnValue }
                });
            }
            catch (Exception ex)
            {
                return null;
            }
            if (dt != null && dt.Rows.Count > 0)
            {
                foreach (DataRow row in dt.Rows)
                {
                    if (row["ROLEID"].ToString() == "21")
                        return row["PHYSICIANID"].ToString();
                }
                return dt.Rows[0]["PHYSICIANID"].ToString();
            }
            else return "Ошибка пользователя!";
        }

        private static string GetConnectionString()
        {
            return System.Configuration.ConfigurationManager.AppSettings["ConnectionString"];
        }
    }
}
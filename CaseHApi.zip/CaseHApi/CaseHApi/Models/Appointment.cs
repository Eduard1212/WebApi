﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Text;
using System.Data.SqlClient;
using CaseHApi.Access;

namespace CaseHApi.Appointment
{
    public sealed class Appoint
    {
        public static DataTable GetAppointList(string session, DateTime from, DateTime to, int? illhID, string illhNUM, string type)
        {
            DataTable dt;

            string connectionString = System.Configuration.ConfigurationManager.AppSettings["ConnectionString"];
            string sqlString = "[dbo].[MedicareService_ListForPost]";
            SqlParameter r;
            try
            {
                dt = SqlHelper.ExecuteDataTable(connectionString, CommandType.StoredProcedure, sqlString, new[] {
                    new SqlParameter("@UserSessionId", SqlDbType.VarChar, 24) { Value = session }
				    , new SqlParameter("@FromDate", SqlDbType.DateTime) { Value = from }
				    , new SqlParameter("@ToDate"  , SqlDbType.DateTime) { Value = to }
				    , new SqlParameter("@LevelTypeList" , SqlDbType.VarChar, 1000) { Value = type == null ? "" : type}
				    , new SqlParameter("@DepartIdList"        , SqlDbType.VarChar, 3000) { Value = ""}
				    , new SqlParameter("@IllHistoryNum", SqlDbType.VarChar, 30) { Value = illhNUM == null ? "" : illhNUM }
                    , new SqlParameter("@PatientLName", SqlDbType.VarChar, 30) { Value = "" }
				    , new SqlParameter("@PatientFName", SqlDbType.VarChar, 30) { Value = "" }
				    , new SqlParameter("@PatientId"     , SqlDbType.Int) { Value = DBNull.Value }
				    , new SqlParameter("@PhysicianId", SqlDbType.Int) { Value = DBNull.Value }
				    , new SqlParameter("@IllHistoryId"  , SqlDbType.Int) { Value = illhID }
                    , new SqlParameter("@DepartIdPrescr"  , SqlDbType.Int) { Value = DBNull.Value}
				    , new SqlParameter("@HospStatus", SqlDbType.TinyInt) { Value = 0}
				    , new SqlParameter("@BuildingId"  , SqlDbType.Int) { Value = DBNull.Value}
				    , new SqlParameter("@WardId"      , SqlDbType.Int) { Value = DBNull.Value}
                    , new SqlParameter("@FloorName", SqlDbType.VarChar, 2) { Value = ""}
				    , new SqlParameter("@IsAno", SqlDbType.TinyInt) { Value = 0}
                    , r = new SqlParameter("@ret", SqlDbType.Int) { Direction = ParameterDirection.ReturnValue }
                });
            }
            catch (Exception ex)
            {
                return null;
            }
            dt.TableName = "appointment";
            return dt;
        }

        public static DataTable GetTypeList(string session)
        {
            DataTable dt = SystemCode_ListByOrder(session);
            return dt;
        }

        public static string UpdateAppoint(string s, int service, int St, string des,
            int phys, decimal pm1, decimal pm2, int room, int desc)
        {
            string retval = "";
            string sqlString = "[dbo].[MsResult_Add]";
            SqlParameter[] par = new SqlParameter[12];

            par[0] = new SqlParameter("@UserSessionId", SqlDbType.VarChar, 24); par[0].Value = s;
            par[1] = new SqlParameter("@ServiceId", SqlDbType.Int); par[1].Value = service;
            par[2] = new SqlParameter("@ResultDate", SqlDbType.DateTime); par[2].Value = DateTime.Now;
            par[3] = new SqlParameter("@StatusId", SqlDbType.Int); par[3].Value = St;
            par[4] = new SqlParameter("@Des", SqlDbType.VarChar, 100); par[4].Value = "";
            par[5] = new SqlParameter("@PhysicianId", SqlDbType.Int); par[5].Value = phys;
            par[6] = new SqlParameter("@PhysParam1", SqlDbType.Decimal); par[6].Value = DBNull.Value;
            par[7] = new SqlParameter("@PhysParam2", SqlDbType.Decimal); par[7].Value = DBNull.Value;
            par[8] = new SqlParameter("@ProcRoomId", SqlDbType.Int); par[8].Value = room;
            par[9] = new SqlParameter("@DescId", SqlDbType.Int); par[9].Value = DBNull.Value;
            //
            par[10] = new SqlParameter("@retval", SqlDbType.Int); par[10].Direction = ParameterDirection.Output;
            par[11] = new SqlParameter("@ret", SqlDbType.Int); par[11].Direction = ParameterDirection.ReturnValue;

            SqlHelper.ExecuteNonQuery(GetConnString(), CommandType.StoredProcedure, sqlString, par);
            if(par[10].Value.ToString() != "")
                retval = par[10].Value.ToString();
            if (par[11].Value.ToString() != "0")
                throw new Exception("System Error. " + par[11].Value.ToString());
            return retval;
        }

        public static string GetPhysicianID(string session)
        {
            DataTable dt;
            string sqlString = "[dbo].[Physician_ListByUserName]";
            SqlParameter ret;
            try
            {
                dt = SqlHelper.ExecuteDataTable(GetConnString(), CommandType.StoredProcedure, sqlString, new[] {
                    new SqlParameter("@UserSessionId", SqlDbType.VarChar, 24) { Value = session }
                    , ret = new SqlParameter("@ret", SqlDbType.Int) { Direction = ParameterDirection.ReturnValue }
                });
            }
            catch (Exception ex)
            {
                return null;
            }
            if (dt != null && dt.Rows.Count > 0)
            {
                foreach (DataRow row in dt.Rows)
                {
                    if (row["ROLEID"].ToString() == "21")
                        return row["PHYSICIANID"].ToString();
                }
                return dt.Rows[0]["PHYSICIANID"].ToString();
            }
            else return "Ошибка пользователя!";
        }

        private static DataTable SystemCode_ListByOrder(string _UserSessionId)
        {
            DataTable tblCurrent = null;
            string connectionString = System.Configuration.ConfigurationManager.AppSettings["ConnectionString"];
            string sqlString = "[dbo].[SystemCode_ListByOrder]";
            SqlParameter[] par = new [] {
                new SqlParameter("@UserSessionId", SqlDbType.VarChar, 24) { Value = _UserSessionId},
                new SqlParameter("@CategoryId", SqlDbType.Int) { Value = 107},
                new SqlParameter("@ParentId", SqlDbType.Int) { Value = DBNull.Value},
                new SqlParameter("@PartyId", SqlDbType.Int) { Value = DBNull.Value},
                new SqlParameter("@Name", SqlDbType.VarChar, 255) { Value = ""},
                new SqlParameter("@SortOrder", SqlDbType.Int) { Value = 3},
                new SqlParameter("@IsActive", SqlDbType.TinyInt) { Value = 1},
                new SqlParameter("@ret", SqlDbType.Int) { Direction = ParameterDirection.ReturnValue } };

            return tblCurrent = SqlHelper.ExecuteDataTable(connectionString, CommandType.StoredProcedure, sqlString, par);
        }

        private static string GetConnString()
        {
            return System.Configuration.ConfigurationManager.AppSettings["ConnectionString"];
        }
    }
}
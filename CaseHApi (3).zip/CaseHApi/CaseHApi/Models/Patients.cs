﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Text;
using System.Data.SqlClient;
using CaseHApi.Access;

namespace CaseHApi.Patients
{
    public sealed class Patient
    {
        public static DataTable GetPatientList(string session, DateTime from, DateTime to, string illhNUM)
        {
            DataTable dt;

            string connectionString = System.Configuration.ConfigurationManager.AppSettings["ConnectionString"];
            string sqlString = "[dbo].[IllHistory_ListForPost]";
            SqlParameter r;
            try
            {
                dt = SqlHelper.ExecuteDataTable(connectionString, CommandType.StoredProcedure, sqlString, new[] {
                    new SqlParameter("@UserSessionId", SqlDbType.VarChar, 24) { Value = session }
                    , new SqlParameter("@IllHistoryNum", SqlDbType.VarChar, 10) { Value = illhNUM }
                    , new SqlParameter("@WardId", SqlDbType.VarChar, 5) { Value = "" }
                    , new SqlParameter("@BuildingId", SqlDbType.Int) { Value = DBNull.Value }
                    , new SqlParameter("@Stor", SqlDbType.VarChar, 5) { Value = "" }
                    , new SqlParameter("@PatientLName", SqlDbType.VarChar, 30) { Value = "" }
                    , new SqlParameter("@PatientFName", SqlDbType.VarChar, 30) { Value = "" }
                    , new SqlParameter("@DepartId", SqlDbType.Int) { Value = DBNull.Value }
                    , new SqlParameter("@HospitStatus", SqlDbType.TinyInt) { Value = 0 }
                    , new SqlParameter("@IsAno", SqlDbType.TinyInt) { Value = 0 }
                    , new SqlParameter("@FromDate", SqlDbType.DateTime) { Value = DBNull.Value }
                    , new SqlParameter("@ToDate", SqlDbType.DateTime) { Value = DBNull.Value }
                    , r = new SqlParameter("@ret", SqlDbType.Int) { Direction = ParameterDirection.ReturnValue }
                });
            }
            catch (Exception ex)
            {
                return null;
            }
            return dt;
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Security.Cryptography;
using System.Text;
using System.Data.SqlClient;
using CaseHApi.Access;
using CaseHApi.UniqueKeyGenerator;

namespace CaseHApi.User
{
    public sealed class UserAuth
    {
        public static bool CheckPassword(string pass, string hash)
        {
            var salt = hash.Substring(0, 16);
            hash = hash.Substring(16, 32);
            var hashdata = MD5.Create().ComputeHash(Encoding.UTF8.GetBytes(pass + salt));
            var hex = string.Join("", hashdata.Select(b => b.ToString("x2")));
            return hex == hash;
        }

        public static DataTable Verification(string log)
        { 
            string connectionString = System.Configuration.ConfigurationManager.AppSettings["ConnectionString"];
            string sqlString = "[dbo].[SystemUser_VerifyLogin]";
            SqlParameter r;
            SqlParameter[] par = new [] {
                    new SqlParameter("@UserName", SqlDbType.VarChar, 30) { Value = log },
                r = new SqlParameter("@ret", SqlDbType.Int)              { Direction = ParameterDirection.ReturnValue }
            };
            if (r.Value != null)
                return null;
            return SqlHelper.ExecuteDataTable(connectionString, CommandType.StoredProcedure, sqlString, par);
        }

        public static int Authorization(string UserSessionId, int UserId, string Login, string IP, string device)
        {
            string connectionString = System.Configuration.ConfigurationManager.AppSettings["ConnectionString"];
            string sqlString = "[dbo].[SystemUserData_Add]";
            SqlParameter r;
            try
            {
                SqlHelper.ExecuteNonQuery(connectionString, CommandType.StoredProcedure, sqlString, new[] {
                    new SqlParameter("@UserSessionId", SqlDbType.VarChar, 24) { Value = UserSessionId },
                    new SqlParameter("@UserId",        SqlDbType.Int)         { Value = UserId },
                    new SqlParameter("@UserIp",        SqlDbType.VarChar, 15) { Value = IP },
                    new SqlParameter("@Description",   SqlDbType.Text)        { Value = string.Format("LogIn user= {0}", Login) },
                    new SqlParameter("@WebServerName", SqlDbType.VarChar, 30) { Value = device },
                    r = new SqlParameter("@ret", SqlDbType.Int)              { Direction = ParameterDirection.ReturnValue }
                });
            } 
            catch(Exception ex)
            {
                return -1;
            }
            return 1;
        }

        public static int Exit(string UserSessionId)
        {
            string connectionString = System.Configuration.ConfigurationManager.AppSettings["ConnectionString"];
            string sqlString = "[dbo].[SystemUser_LogOff]";
            SqlParameter r;
            try
            {
                SqlHelper.ExecuteNonQuery(connectionString, CommandType.StoredProcedure, sqlString, new[] {
                    new SqlParameter("@UserSessionId", SqlDbType.VarChar, 24) { Value = UserSessionId },
                    r = new SqlParameter("@ret", SqlDbType.Int)              { Direction = ParameterDirection.ReturnValue }
                });
            }
            catch (Exception ex)
            {
                return -1;
            }
            return 1;
        }
    }
}